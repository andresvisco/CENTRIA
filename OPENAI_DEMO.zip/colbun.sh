#!/bin/bash
echo "Demo CENTRIA - ARKANO - MICROSOFT - OPENAI"
export OPENAI_API_KEY="430f140c6a1d4518900a39d4e7c452cd"
export AZURE_ENDPOINT="DefaultEndpointsProtocol=https;AccountName=avsacscentria;AccountKey=rinCmTiCzV5C/Pcsw+k2hN22K8SDVBGv32H9gsfQxgvt+Exp3jIax3vlNS9Gesa5KnfW1wwWgWsk+ASt03irEA==;EndpointSuffix=core.windows.net"
export OPENAI_API_KEY_FORM="4ff61ad27d0e417b93ea5ee0e60c01a3"
streamlit run Inicio.py

